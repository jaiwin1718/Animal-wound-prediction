# Animal-Wound-Prediction
Detecting Animal Wound using YOLOV5 

Clone the repository
Run the colab file for installing packages and requirements
Inside YOLOV5 directory upload wund.yaml file
Upload the project zip file and extract it using the given code
Run the remaining code for getting the output
